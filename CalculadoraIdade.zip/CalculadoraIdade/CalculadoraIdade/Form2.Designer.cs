﻿namespace CalculadoraIdade
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            txtIdadeAtual = new TextBox();
            btnCalcular = new Button();
            txtAnoPretendido = new TextBox();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 25);
            label1.Name = "label1";
            label1.Size = new Size(89, 20);
            label1.TabIndex = 0;
            label1.Text = "Idade Atual:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(-1, 113);
            label2.Name = "label2";
            label2.Size = new Size(116, 20);
            label2.TabIndex = 1;
            label2.Text = "Ano Pretendido:";
            // 
            // txtIdadeAtual
            // 
            txtIdadeAtual.Location = new Point(149, 25);
            txtIdadeAtual.Name = "txtIdadeAtual";
            txtIdadeAtual.Size = new Size(125, 27);
            txtIdadeAtual.TabIndex = 2;
            // 
            // btnCalcular
            // 
            btnCalcular.Location = new Point(133, 246);
            btnCalcular.Name = "btnCalcular";
            btnCalcular.Size = new Size(94, 29);
            btnCalcular.TabIndex = 4;
            btnCalcular.Text = "Calcular";
            btnCalcular.UseVisualStyleBackColor = true;
            btnCalcular.Click += btnCalcular_Click;
            // 
            // txtAnoPretendido
            // 
            txtAnoPretendido.Location = new Point(149, 113);
            txtAnoPretendido.Name = "txtAnoPretendido";
            txtAnoPretendido.Size = new Size(125, 27);
            txtAnoPretendido.TabIndex = 5;
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(txtAnoPretendido);
            Controls.Add(btnCalcular);
            Controls.Add(txtIdadeAtual);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form2";
            Text = "Form2";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private TextBox txtIdadeAtual;
        private Button btnCalcular;
        private TextBox txtAnoPretendido;
    }
}