﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CalculadoraIdade
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            int idadeAtual, anoPretendido;

            if (!int.TryParse(txtIdadeAtual.Text.Trim(), out idadeAtual) ||
                !int.TryParse(txtAnoPretendido.Text.Trim(), out anoPretendido))
            {
                MessageBox.Show("Digite valores válidos!");
                return;
            }

            Pessoa pessoa = new Pessoa(idadeAtual);
            int idadeFutura = pessoa.CalcularIdadeFutura(anoPretendido);

            if (idadeFutura < 0)
            {
                MessageBox.Show($"Em {anoPretendido}, você ainda não havia nascido.");
                return;
            }

            string categoria = ClassificarIdade(idadeFutura);

            MessageBox.Show($"Em {anoPretendido}, você {(anoPretendido > DateTime.Now.Year ? "terá" : "tinha")} {idadeFutura} anos.\nClassificação: {categoria}");
        }

        private string ClassificarIdade(int idade)
        {
            switch (idade)
            {
                case int n when n < 12:
                    return "Criança";
                case int n when n >= 12 && n < 18:
                    return "Adolescente";
                case int n when n >= 18 && n < 60:
                    return "Adulto";
                default:
                    return "Idoso";
            }
        }
    }
}