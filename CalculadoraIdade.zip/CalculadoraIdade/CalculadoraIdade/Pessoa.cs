﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalculadoraIdade
{
    public class Pessoa
    {
        public int IdadeAtual { get; set; }

        public Pessoa(int idadeAtual)
        {
            IdadeAtual = idadeAtual;
        }

        public int CalcularIdadeFutura(int anoPretendido)
        {
            int anoAtual = DateTime.Now.Year;
            int idadeCalculada = IdadeAtual;

            if (anoPretendido > anoAtual)
            {
                for (int i = anoAtual; i < anoPretendido; i++)
                {
                    idadeCalculada++;
                }
            }
            else if (anoPretendido < anoAtual)
            {
                for (int i = anoAtual; i > anoPretendido; i--)
                {
                    idadeCalculada--;
                }
            }

            return idadeCalculada;
        }
    }
}